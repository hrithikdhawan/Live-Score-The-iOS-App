//
//  ViewController.swift
//  Live Score
//
//  Created by Siddharth Dhawan on 31/01/18.
//  Copyright © 2018 Siddharth Dhawan. All rights reserved.
//

import UIKit

var Selected = [false ,false ,false]

let SportsList = ["Football" ,"Cricket","Basketball"]

let defaults = UserDefaults.standard

class SportsCell : UITableViewCell
{
    @IBOutlet weak var cellSwitch: UISwitch!
    @IBOutlet weak var cellLabel: UILabel!
    @IBAction func cellSwitched(_ sender: UISwitch)
    {
        if sender.isOn
        {
            Selected[cellLabel.tag] = true
            cellLabel.textColor = .blue
        }
        else
        {
            Selected[cellLabel.tag] = false
            cellLabel.textColor = .black
        }
        defaults.set(Selected[cellLabel.tag], forKey: SportsList[cellLabel.tag])
        
    }
}

class FirstViewController: UITableViewController
{
    @IBOutlet var myTableView: UITableView!
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        tableView.separatorStyle = .none
        return SportsList.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "sportscell", for: indexPath) as! SportsCell
        cell.cellLabel.text = SportsList[indexPath.row]
        cell.cellLabel.textColor = .black
        cell.cellLabel.tag = indexPath.row
        cell.cellSwitch.setOn(false, animated: true)
        return cell
    }
    @IBAction func done(_ sender: UIBarButtonItem)
    {
        performSegue(withIdentifier: "secondScreen", sender: sender)
    }
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //let height: CGFloat = 36 //whatever height you want to add to the existing height
       // let bounds = self.navigationBar.bounds
        
       // self.navigationBar.frame = CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height + height)
       // print(bounds.height)
        myTableView.reloadData()
        for index in 0...SportsList.count-1
        {
            let value = [SportsList[index] : Selected[index]]
            defaults.register(defaults: value)
        }
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

