//
//  NavigationController.swift
//  Live Score
//
//  Created by Siddharth Dhawan on 03/03/18.
//  Copyright © 2018 Siddharth Dhawan. All rights reserved.
//

import UIKit
class NavigationController : UINavigationController
{
    override func viewDidLayoutSubviews() {
    super.viewDidLayoutSubviews()
    let height = CGFloat(80)
    navigationBar.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: height)
    }
}
